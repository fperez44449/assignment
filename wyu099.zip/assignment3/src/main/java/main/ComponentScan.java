package main;

public @interface ComponentScan {

}

package main;

public class Person {
public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		
		this.firstName = firstName;
		
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

private String firstName;
private String LastName;
private int age;
private String dateOfBirth;
private int id;

public Person(String firstName,int age, String lastname, String DateofBirth,int id) {
		this.firstName = firstName;
		if(firstName.length()>100||firstName.length()<1){
			System.out.print("ERROOR");
			return;
		}
		if(lastname.length()>100||lastname.length()<1){
			System.out.print("ERROOR");
			return;
		}
		char slash = '/';
		int z = 0;
		System.out.println(DateofBirth);//.length()
		for (int i1 = 0; i1 < DateofBirth.length(); i1++) {
			if (DateofBirth.charAt(i1) == slash) {
				z++;
				continue;
			}
			if (z == 2) {
				String year = String.valueOf(DateofBirth.charAt(i1));
				year = year + String.valueOf(DateofBirth.charAt(i1 + 1));
				int inum = Integer.parseInt(year);
				if(inum > 120){
					System.out.println("PAST CURRENT YEAR");
					return;
				}
				int d = -1;
				
				for (i1 = inum; i1 < 120; i1++, d++) {
					d++;
					i1++;
				}
				this.setAge(d);
				break;
			}
		}
	this.LastName=lastname;
	this.dateOfBirth=DateofBirth;
	this.setId(id);
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public int getAge() {
	return age;
}

public void setAge(int i) {
	this.age = i;
}
}

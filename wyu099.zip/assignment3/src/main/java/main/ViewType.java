package main;

public enum ViewType {
LoginView,SecondView, PersonView
}
